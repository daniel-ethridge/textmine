# textmine
Package for text mining
